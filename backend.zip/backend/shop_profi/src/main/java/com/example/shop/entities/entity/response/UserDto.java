package com.example.shop.entities.entity.response;

public interface UserDto {
    Long getId();
    String getUsername();
    String getName();
    String getEmail();
    String getAddress();
}
