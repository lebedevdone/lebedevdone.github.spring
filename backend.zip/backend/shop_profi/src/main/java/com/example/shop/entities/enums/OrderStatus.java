package com.example.shop.entities.enums;

public enum OrderStatus {
    NEW,
    PROCESSED,
    SENT,
    COMPLETED,
    CANCELLED
}
