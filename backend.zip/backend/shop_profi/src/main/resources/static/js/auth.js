const loginBtn = document.getElementById('authButton');

loginBtn.addEventListener('click', function (event) {

});